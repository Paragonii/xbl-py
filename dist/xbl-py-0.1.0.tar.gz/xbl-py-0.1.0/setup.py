# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['xbl_py']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['xbl-py = xbl-py:main']}

setup_kwargs = {
    'name': 'xbl-py',
    'version': '0.1.0',
    'description': 'An Xbox Live API wrapper for Python',
    'long_description': '',
    'author': 'Paragon',
    'author_email': 'helloworldpy103@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/Paragonii/xbl-py',
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
